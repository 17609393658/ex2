package sqldemo;

public class SetDriver {

	public boolean codeJudge() {
		// TODO Auto-generated method stub
		return false;
	}

}
